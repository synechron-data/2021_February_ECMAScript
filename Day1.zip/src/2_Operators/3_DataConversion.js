// Type Casting - Between Similiar (Same Family of) Types int to float, float to int  [int a = (int)10.5]
// Type Conversion - Different Family of types                  int to string, string to float

// JavaScript supports only Type Conversion

// var data = window.prompt("Enter a number: ", 0);
// // console.log(typeof data);

// var d1 = data + 10;
// console.log(d1);

// var d2 = parseInt(data) + 10;
// console.log(d2);

// var d3 = parseFloat(data) + 10;
// console.log(d3);

// var d4 = Number(data) + 10;
// console.log(d4);

// var obj;
var obj = null;
// var obj = {};

// if ((obj === undefined) || (obj === null)) {
//     console.error("Object Is undefined or null");
// } else {
//     console.log("Object Is not undefined or null");
// }

// if (!obj) {
//     console.error("Object Is undefined or null");
// } else {
//     console.log("Object Is not undefined or null");
// }

// console.log(Boolean(1));
// console.log(Boolean(0));
// console.log(Boolean(-1));
// console.log(Boolean("ABC"));
// console.log(Boolean(""));
// console.log(Boolean(null));
// console.log(Boolean(undefined));
// console.log(Boolean({}));

console.log(true && "ABC");
console.log(true && "ABC" || "XYZ");
console.log(false && "ABC" || "XYZ");

{/* <h1 class="{{isSelected() && "info" || "success"}}"></h1> */ }
{/* <h1 class={isSelected() && "info" || "success"}></h1> */}