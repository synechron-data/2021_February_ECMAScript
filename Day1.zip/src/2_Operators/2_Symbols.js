// const color = "red";

// function check(str){
//     console.log(str === color);
// }

// check(color);
// check("red");

// var clr = "red";
// check(clr);

// -------------------------------------

// const color = { clr: "red" };

// function check(str) {
//     console.log(str === color);
// }

// check(color);
// check({ clr: "red" });

// var clr = { clr: "red" };
// check(clr);

// -------------------------------------
const color = Symbol("red");

function check(str){
    console.log(str === color);
}

check(color);
check(Symbol("red"));

var clr = Symbol("red");
check(clr);