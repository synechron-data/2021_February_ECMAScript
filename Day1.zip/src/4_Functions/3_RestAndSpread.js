// If I use ... on Lefthand side of assignment Operator (Rest)
// If I use ... on Righthand side of assignment Operator (Spread)

// In ECMAScript 2015, we can use ... only with Iterable Objects
// In ECMAScript 2018, we can use ... with Objects also

// ----------------------------------------------------------------- Array Spread

// var arr1 = [10, 20, 30, 40, [50, 60, 70, 80, 90]];

// var arr2 = arr1;

// Shallow Copy
// var arr2 = arr1.slice();
// var arr2 = [].concat(arr1);
// var arr2 = [...arr1];

// Deep Copy
// var arr2 = JSON.parse(JSON.stringify(arr1));

// arr2[0] = 1000;
// arr2[4][0] = 5000;

// console.log("Array 1", arr1);
// console.log("Array 2", arr2);

// -----------------------------

// var arr1 = [10, 20, 30, 40];
// var arr2 = [50, 60, 70, 80];

// // var arr3 = [].concat(arr1, arr2);
// // var arr3 = arr1.concat(arr2);
// var arr3 = [...arr1, ...arr2];

// console.log("Array 1", arr1);
// console.log("Array 2", arr2);
// console.log("Array 3", arr3);

// ----------------------------------------------------------------- Array Destructuring & Rest

var arr = [10, 20, 30, 40, 50, 60, 70, 80, 90];

// ES5 - Destructuring
// var x = arr[0];
// var y = arr[1]

// ES2015 - Destructuring

// var [x, y] = arr;
// var [x, , y] = arr;
// console.log(`x = ${x}, y = ${y}`);

// ES2015 - Destructuring wit Rest
// var [x, y, ...z] = arr;
// console.log(`x = ${x}, y = ${y}, z = ${z}`);

// var [x, y] = arr;

// console.log(`Before Swap, x = ${x}, y = ${y}`);

// [x, y] = [y, x];

// console.log(`After Swap, x = ${x}, y = ${y}`);