import '../public/favicon.ico';

// console.log("Main File Loaded....");

// import './1_DataTypes/1_Declarations';
// import './1_DataTypes/2_ES6_Declarations';
// import './1_DataTypes/3_ES6_Const';

// (function () {
//     // Code of File1
//     const i = 10;
// })();

// (function () {
//     // Code of File2
//     const i = 20;
// })();

// import './1_DataTypes/4_DataTypes';

// import './2_Operators/1_Equality';
// import './2_Operators/2_Symbols';
// import './2_Operators/3_DataConversion';

// import './3_CertainConditions/1_Loops';
// import './3_CertainConditions/2_Statements';

// import './4_Functions/1_FnCreation';
// import './4_Functions/2_FnParameters';
// import './4_Functions/3_RestAndSpread';
// import './4_Functions/4_PureAndImpureFn';
// import './4_Functions/5_ArrowFn';
// import './4_Functions/6_FnAsArgument';
// import './4_Functions/7_IIFE';
// import './4_Functions/8_FnOverloading';
import './4_Functions/9_Assignment';


