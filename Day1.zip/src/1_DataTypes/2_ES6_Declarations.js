// let a = 10;
// console.log("a is: ", a);

// a = "Hello";
// console.log("a is: ", a);

// Hoisting - Hoisting is JavaScript's Runtime default behavior of 
// moving declarations to the top.

// It will work only when you compile the code
// let keyword is not hoisted by default
// a = 10;
// console.log("a = ", a);
// var a = 10;

// // Runtime sees the below code
// var a;
// console.log("a = ", a);
// a = 10;

// let a = 10;
// let a = "Hello";
// console.log("a is: ", a);

// ES 2015 with let keyword supports
// Global Scope
// Function (local) Scope
// Block Scope

// var i = "Hello";
// console.log("Before, i is", i);

// for (let i = 0; i < 5; i++) {
//     console.log("Inside Loop, i is", i);
// }

// console.log("After, i is", i);