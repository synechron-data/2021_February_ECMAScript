// console.log("Declarations.js loaded....");

// var a = 10;
// console.log("a = ", a);

// Hoisting - Hoisting is JavaScript's Runtime default behavior of 
// moving declarations to the top.

// a = 10;
// console.log("a = ", a);
// var a;

// Not TypeSafe
// var a = 10;
// console.log("a = ", a);
// a = "Hello";
// console.log("a = ", a);

// var a = 10;
// var a = "Hello";
// console.log("a = ", a);

// var keyword does not give block scoping, 
// Only Global and Function Scope is supported when using var keyword

var i = "Hello";
console.log("Before, i is", i);

for (var i = 0; i < 5; i++) {
    console.log("Inside Loop, i is", i);
}

// function iterate() {
//     for (var i = 0; i < 5; i++) {
//         console.log("Inside Loop, i is", i);
//     }
// }

// iterate();

// IIFE - Immediatly Invoked Function Expression
// (function () {
//     for (var i = 0; i < 5; i++) {
//         console.log("Inside Loop, i is", i);
//     }
// })();

console.log("After, i is", i);