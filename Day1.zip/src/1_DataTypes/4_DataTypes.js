var language;
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);

language = null;
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);

language = 10;
// language = 10.5;
// language = 0b1001;
// language = 0o1001;
// language = 0x1001;
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);

// language = "JavaScript";
// language = 'JavaScript';

// ES 6 - Template/String Literal
// language = `Java

// Script`;

var d1 = "Java";
var d2 = "Script";
// language = d1 + d2;
language = `${d1}${d2}`;

console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);

language = true;
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);

// ES 6 - Symbol ( You cannot use new keyword)
language = Symbol("Hello");
// language = new Symbol("Hello");
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);

language = new Object();
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);

language = "Hello";
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);

language = String("Hello");
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);

language = new String("Hello");
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);