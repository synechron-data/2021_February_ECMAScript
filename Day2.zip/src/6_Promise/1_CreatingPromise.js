var promise = new Promise((resolve, reject) => {
    setTimeout(function () {
        // resolve("Hello, it is a success");
        reject("It is an error");
    }, 5000);
});

// console.log(promise);

// promise.then(msg => {
//     console.log("Success: ", msg);
// }, emsg => {
//     console.error("Error: ", emsg);
// });

// promise.then(msg => {
//     console.log("Success: ", msg);
// }).catch(emsg => {
//     console.error("Error: ", emsg);
// });

promise.then(msg => {
    console.log("Success: ", msg);
}).catch(emsg => {
    console.error("Error: ", emsg);
}).finally(()=>{
    console.log("Finally always run's");
});