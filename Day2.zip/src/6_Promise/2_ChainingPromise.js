var firstMethod = function () {
    var promise = new Promise((resolve, reject) => {
        setTimeout(function () {
            console.log('first method completed');
            resolve({ first: 'From first method' });
        }, 2000);
    });
    return promise;
};

var secondMethod = function (input) {
    var promise = new Promise((resolve, reject) => {
        setTimeout(function () {
            console.log('second method completed');
            resolve({ first: input.first, second: 'From second method' });
            // reject("Second Method Error");
        }, 2000);
    });
    return promise;
};

var thirdMethod = function (input) {
    var promise = new Promise((resolve, reject) => {
        setTimeout(function () {
            console.log('third method completed');
            var data = Object.assign({}, input);
            data.third = 'From third method';
            resolve(data);
        }, 3000);
    });
    return promise;
};

firstMethod().then(secondMethod).then(thirdMethod).then(data => {
    console.log("Final Result: ", data);
}).catch(emsg => {
    console.error(emsg);
});