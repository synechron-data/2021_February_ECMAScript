// var employees = new Array();
// var employees = new Array(2);
// var employees = new Array("Manish", "Subodh", "Abhijeet");
// var employees = new Array(10,20);
// var employees = new Array([10, 20, 30, 40]);
// var employees = new Array("Manish");

// var employees = Array.from([10, 20, 30, 40]);
// var employees = Array.from("Manish");

// var employees = Array.of(10);

// var employees = ["Manish"];

// employees[10] = "Abhijeet";
// // employees[2] = "Ramakant";

// employees.push("Abhijeet");
// employees.push("Ramakant");
// employees.unshift("Neeraj");

// console.log(employees);
// console.log(employees.length);

// --------------------------------------------------- Iterate

// var employees = [
//     { id: 1, name: "Manish" },
//     { id: 2, name: "Varun" },
//     { id: 3, name: "Paresh" },
//     { id: 4, name: "Devesh" },
//     { id: 5, name: "Atul" },
//     { id: 6, name: "Abhishek" }
// ];

// for (let i = 0; i < employees.length; i++) {
//     console.log(`${i}           ${JSON.stringify(employees[i])}`);
// }

// for (const i in employees) {
//     console.log(`${i}           ${JSON.stringify(employees[i])}`);
// }

// employees.forEach((item, index, arr) => {
//     console.log(`${index}           ${JSON.stringify(item)}`);
// });

// for (const item of employees) {
//     console.log(`${JSON.stringify(item)}`);
// }

// for (const [index, item] of employees.entries()) {
//     console.log(`${index}           ${JSON.stringify(item)}`);
// }

// --------------------------------------------------- Array Methods

// var employees = [
//     { id: 1, name: "Manish" },
//     { id: 2, name: "Varun" },
//     { id: 3, name: "Paresh" },
//     { id: 4, name: "Devesh" },
//     { id: 5, name: "Atul" },
//     { id: 6, name: "Abhishek" }
// ];

// Filter
// var filtered = employees.filter(item => item.name.startsWith('A'));
// console.log(filtered);

// var filtered = employees.filter(item => item.name === "Manish");
// console.log(filtered);

// Find
// var employee = employees.find(item => item.name === "Manish");
// console.log(employee);

// var employee_index = employees.findIndex(item => item.name === "Manish");
// console.log(employee_index);

// Transformation
// var names = employees.map(item => item.name.toUpperCase());
// console.log(names);

// Reduce
// var numbers = [10, 20, 30, 40, 50];

// var sum = numbers.reduce((acc, item) => acc + item);
// console.log(sum);