const BankAccount = (function () {
    function BankAccount(accName) {
        this._accName = accName;
    }

    Object.defineProperty(BankAccount, "BankName", {
        set: function (value) {
            BankAccount._bankName = value;
        }
    });

    Object.defineProperty(BankAccount.prototype, "BankName", {
        get: function () {
            return BankAccount._bankName;
        }
    });

    Object.defineProperty(BankAccount.prototype, "AccountName", {
        get: function () {
            return this._accName;
        }
    });

    return BankAccount;
})();

BankAccount.BankName = "HDFC";

var a1 = new BankAccount("Manish");
console.log("\nBank Name:", a1.BankName);
console.log("Account Holder Name:", a1.AccountName);

var a2 = new BankAccount("Abhijeet");
console.log("\nBank Name:", a2.BankName);
console.log("Account Holder Name:", a2.AccountName);

console.log("\n");

BankAccount.BankName = "ICICI";

var a1 = new BankAccount("Manish");
console.log("\nBank Name:", a1.BankName);
console.log("Account Holder Name:", a1.AccountName);

var a2 = new BankAccount("Abhijeet");
console.log("\nBank Name:", a2.BankName);
console.log("Account Holder Name:", a2.AccountName);

// console.log(a1);
// console.log(a2);