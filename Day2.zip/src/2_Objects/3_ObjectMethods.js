// ---------------------------------------------------- Object.assign (ES2015)
// let source = { id: 1, name: "Manish", address: { city: "Pune" } };

// let target = source;
// target.name = "Abhijeet";

// Shallow Copy
// let target = Object.assign({}, source);
// target.name = "Abhijeet";
// target.address.city = "Mumbai";

// Deep Copy
// let target = JSON.parse(JSON.stringify(source));
// target.name = "Abhijeet";
// target.address.city = "Mumbai";

// console.log("Source: ", source);
// console.log("Target: ", target);

// ---------------------------------------------------- Object.create
// Creates a new object, using an existing object as the prototype of the newly created object.

// let source = { id: 1, name: "Manish", address: { city: "Pune" } };

// let target1 = Object.assign({}, source);
// let target2 = Object.create(source);

// console.log("Source: ", source);
// console.log("Object.Assign: ", target1);
// console.log("Object.Create: ", target2);

// ----------------------------------------------------

// let source = { id: 1, name: "Manish" };

// // Modify Property Value
// source.id = 100;
// console.log(source);

// // Delete a Property
// delete source.id;
// console.log(source);

// // Add new Property
// source.city = "Pune";
// console.log(source);

// // ---------------------------------------------------- preventExtensions()
// // Modify Property Value - Allowed
// // Delete a Property - Allowed
// // Add new Property - Not Allowed

// let source = { id: 1, name: "Manish" };

// Object.preventExtensions(source);

// source.id = 100;
// console.log(source);

// delete source.id;
// console.log(source);

// if (Object.isExtensible(source)) {
//     source.city = "Pune";
//     console.log(source);
// }

// // ---------------------------------------------------- seal()
// // Modify Property Value - Allowed
// // Delete a Property - Not Allowed
// // Add new Property - Not Allowed

// let source = { id: 1, name: "Manish" };

// Object.seal(source);

// source.id = 100;
// console.log(source);

// if (!Object.isSealed(source)) {
//     delete source.id;
//     console.log(source);

//     source.city = "Pune";
//     console.log(source);
// }

// ---------------------------------------------------- freeze()
// Modify Property Value - Not Allowed
// Delete a Property - Not Allowed
// Add new Property - Not Allowed

let source = { id: 1, name: "Manish" };

Object.freeze(source);

if (!Object.isFrozen(source)) {
    source.id = 100;
    console.log(source);

    delete source.id;
    console.log(source);

    source.city = "Pune";
    console.log(source);
}