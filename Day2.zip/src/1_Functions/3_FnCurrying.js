// function greetings(message, name) {
//     return `${message}, ${name}`;
// }

// console.log(greetings("Good Morning", "Abhijeet"));
// console.log(greetings("Good Morning", "Ramakant"));
// console.log(greetings("Good Morning", "Pravin"));

// function Converter(toUnit, factor, offset, input) {
//     return [((offset + input) * factor).toFixed(2), toUnit].join("");
// }

// console.log(Converter(" INR", 73, 0, 100));
// console.log(Converter(" INR", 73, 0, 150));
// console.log(Converter(" INR", 73, 0, 290));
// console.log(Converter(" INR", 73, 0, 999));

// -------------------------------------------------------------------------------------

// function greetings(message) {
//     return function (name) {
//         return `${message}, ${name}`;
//     }
// }

// var mGreet = greetings("Good Morning");

// console.log(mGreet("Abhijeet"));
// console.log(mGreet("Ramakant"));
// console.log(mGreet("Pravin"));

// var aGreet = greetings("Good Afternoon");

// console.log(aGreet("Abhijeet"));
// console.log(aGreet("Ramakant"));
// console.log(aGreet("Pravin"));

// function Converter(toUnit, factor, offset) {
//     return function (input) {
//         return [((offset + input) * factor).toFixed(2), toUnit].join("");
//     }
// }

// var usdToInr = Converter(" INR", 73, 0);

// console.log(usdToInr(100));
// console.log(usdToInr(150));
// console.log(usdToInr(290));
// console.log(usdToInr(999));

// var milesToKm = Converter(" KM", 1.6, 0);

// console.log(milesToKm(100));
// console.log(milesToKm(150));
// console.log(milesToKm(290));
// console.log(milesToKm(999));

// -------------------------------------------------------------------------

function greetings(message, name) {
    return `${message}, ${name}`;
}

var mGreet = greetings.bind(undefined, "Good Morning");

console.log(mGreet("Abhijeet"));
console.log(mGreet("Ramakant"));
console.log(mGreet("Pravin"));

function Converter(toUnit, factor, offset, input) {
    return [((offset + input) * factor).toFixed(2), toUnit].join("");
}

var milesToKm = Converter.bind(undefined, " KM", 1.6, 0);

console.log(milesToKm(100));
console.log(milesToKm(150));
console.log(milesToKm(290));
console.log(milesToKm(999));