import apiClient from "./apiClient";

var button = document.createElement("button");
button.innerHTML = "GET DATA";

var body = document.getElementsByTagName("body")[0];
body.appendChild(button);

button.addEventListener("click", function () {
    // console.log("Button Clicked....");

    // apiClient.getAllPosts((data) => {
    //     console.log(data);
    // }, (emsg) => {
    //     console.error(emsg);
    // });

    apiClient.getAllPostsUsingPromise().then((data) => {
        console.log(data);
    }).catch((emsg) => {
        console.error(emsg);
    });
});